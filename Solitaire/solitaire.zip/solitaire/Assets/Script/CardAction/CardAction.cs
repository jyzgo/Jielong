﻿using UnityEngine;
using System.Collections;

public abstract class CardAction  {
    public abstract void DoAction();
    public abstract void ReverseAction();


}
